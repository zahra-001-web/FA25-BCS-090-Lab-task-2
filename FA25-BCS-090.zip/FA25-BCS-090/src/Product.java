public class Product{
    int productId;
    double price;
    public Product(int productId, double price){
        this.productId = productId;
        this.price = price;
    }
    public void sell(){
        System.out.println("Your product selling is: " + productId + " Price: " + price);

    }
    public void display(){
        System.out.println("Product Id: " + productId + " Price: " + price);

    }
    public String toString(){
        return String.format("Product Id: %d, Price: %.2f", productId, price);
    }
}