public class SmartPhone extends ElectronicProduct {
    int ram;
    double cameraMp;
    public SmartPhone(int productId, double price,String brand,int warrantyYears, int ram, double cameraMp) {
        super(productId,price,brand,warrantyYears);
        this.ram = ram;
        this.cameraMp = cameraMp;
    }
    @Override
    public void display(){
        super.display();
        System.out.println("Product Id: " + productId + " Price: " + price);

    }
    @Override
    public String toString(){
        return String.format("Product Id: %d, Price: %.2f, Brand : %s , Warranty Years : %04d ,RAM : %04d, Camera MP: %f", productId, price,brand, warrantyYears,ram, cameraMp);
    }

}
