public class Demo {
    public static void main(String[] args) {
        Product P=new Product(123,214.9);
        ElectronicProduct E=new ElectronicProduct(24,45.89,"Samsung",2028);
        SmartPhone S=new SmartPhone(245,678.9,"Samsung",2029,11,67.5);
        P.sell();
        P.display();
        E.display();
        S.display();
    }
}
