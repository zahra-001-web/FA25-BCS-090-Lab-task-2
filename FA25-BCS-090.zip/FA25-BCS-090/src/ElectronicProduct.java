public class ElectronicProduct extends Product{
    String brand;
    int warrantyYears;
    public ElectronicProduct(int productId,double price, String brand, int warrantyYears){
        super(productId,price);
        this.brand = brand;
        this.warrantyYears = warrantyYears;

    }
    @Override
    public void display(){
        super.display();
        System.out.println("Product Id: " + productId + " Price: " + price);

    }
@Override
    public String toString(){
        return String.format("Product Id: %d, Price: %.2f, Brand : %s , Warranty Years : %04d", productId, price,brand, warrantyYears);
}


}
